package com.model;

public class Paciente {

	private String nome;
	private double peso;
	private double altura;
	
	public boolean setPeso(double peso)
	{
		if (peso > 0)
		{
			this.peso = peso;
			return true;
		}
		
		return false;
	}
	
	public double getPeso() {
		return this.peso;
	}
	
	public void setAltura(double novaAltura) {
		this.altura = novaAltura;
	}

	public String getNome() {
		return this.nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getAltura() {
		return this.altura;
	}
	
	
	
}
