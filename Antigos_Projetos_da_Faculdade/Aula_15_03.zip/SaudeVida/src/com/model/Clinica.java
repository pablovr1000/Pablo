package com.model;

import java.util.Scanner;

public class Clinica {

	String nome;
	Paciente[] pacientes;	
	
	public Clinica() {
		pacientes = new Paciente[3];
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Digite o nome da Clinica:");
		nome = scan.nextLine();
		
		for (int i = 0; i < 3; i++) {
			Paciente paciente = new Paciente();
			adicionarPaciente(paciente, i);
			pacientes[i] = paciente;
		}
	}
	
	public void adicionarPaciente(Paciente paciente, int indicePaciente)	{
		Scanner scan = new Scanner(System.in);
		System.out.println("Digite o nome do paciente " + indicePaciente);
		String nomePaciente = scan.nextLine();
		System.out.println("Peso do paciente " + indicePaciente);
		double pesoPaciente = scan.nextDouble();
		System.out.println("Altura do paciente " + indicePaciente);
		double alturaPaciente = scan.nextDouble();
		
		paciente.setNome(nomePaciente);
		
		while (!paciente.setPeso(pesoPaciente))
		{
			System.out.println("Digite peso correto");			
			pesoPaciente = scan.nextDouble();
		}
		
		paciente.setAltura(alturaPaciente);
	}
	
	public void mostrarPacientes()	{
		for (Paciente p : pacientes) {
			System.out.println("Nome Paciente: " + p.getNome());
			System.out.println("Peso Paciente: " + p.getPeso());
			System.out.println("Altura Paciente: " + p.getAltura());
		}
	}
	
	public String obterNome() {
		return nome;
	}
	
	public static void main(String[] args) {
		Clinica clinica = new Clinica();
		
		System.out.println("Nome da Clinica:");
		String nomeClinica = clinica.obterNome();
		System.out.println(nomeClinica);
		
		clinica.mostrarPacientes();
	}

}
