package edu.bibliotecadigital.model;

import java.util.Date;

public class LivroImpresso extends Livro {
	
	/* Construtor padr�o
	public LivroImpresso(){
		super();
	}
	 */
	
	public LivroImpresso(String nomeLivro) {
		// implicitamente super();
		super(nomeLivro);
		
		super.setImpresso(true);
	}
	
	private Date dataImpressao;

	public Date getDataImpressao() {
		return dataImpressao;
	}

	public void setDataImpressao(Date dataImpressao) {
		this.dataImpressao = dataImpressao;
	}
	
	
}
