package edu.bibliotecadigital.model;

public class Livro {

	/* Construtor padr�o
	public Livro(){
		super();
	}
	 */	
	
	public Livro(String nomeLivro) {
		// implicitamente chama super();
		
		this.setNome(nomeLivro);
	}
	
	private String nome;
	private String isbn;
	private String descricao;
	private boolean impresso;
		
	
	public boolean isImpresso() {
		return impresso;
	}
	
	protected void setImpresso(boolean impresso) {
		this.impresso = impresso;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}	
	
	
}
