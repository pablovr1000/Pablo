package edu.bibliotecadigital.model;

public class Ebook extends Livro {

	/* Construtor padr�o
	public Ebook(){
		super();
	}
	 */
	
	public Ebook(String nomeLivro) {
		// implicitamente chamar super();
		super(nomeLivro);
		
		super.setImpresso(false);
	}
	
	private String url;

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	
	
	
}
