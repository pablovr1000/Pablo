package edu.bibliotecadigital;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import edu.bibliotecadigital.model.Ebook;
import edu.bibliotecadigital.model.Livro;
import edu.bibliotecadigital.model.LivroImpresso;

public class BibliotecaDigital {

	public static void main(String[] args) {
		
		List<Livro> acervo = new ArrayList<Livro>();
		
		Ebook ebook = new Ebook("Programa��o OO");
		ebook.setIsbn("123");
		ebook.setDescricao("Introdu��o a POO");
		ebook.setUrl("http://livros.com/introducaopoo");
		acervo.add(ebook);
		
		LivroImpresso livroImpresso = new LivroImpresso("Conceitos POO");
		livroImpresso.setIsbn("456");
		livroImpresso.setDescricao("Conceitos de POO");
		livroImpresso.setDataImpressao(Calendar.getInstance().getTime());
		acervo.add(livroImpresso);
		
		for (Livro livro : acervo) {
			System.out.println(livro.getNome());
			System.out.println(livro.getIsbn());
			System.out.println(livro.getDescricao());
			
			if (livro instanceof Ebook) {
				System.out.println(((Ebook)livro).getUrl());
			}
			else {
				System.out.println(((LivroImpresso)livro).getDataImpressao());
			}
		}
		
		/*
		System.out.println("Ebook:");
		System.out.println(ebook.getNome());
		System.out.println(ebook.getIsbn());
		System.out.println(ebook.getDescricao());
		System.out.println(((Ebook)ebook).getUrl());
		System.out.println("Impresso: " + ebook.isImpresso());
		
		System.out.println("Livro Impresso");
		System.out.println(livroImpresso.getNome());
		System.out.println(livroImpresso.getIsbn());
		System.out.println(livroImpresso.getDescricao());
		System.out.println(((LivroImpresso)livroImpresso).getDataImpressao());
		System.out.println("Impresso: " + livroImpresso.isImpresso());
		*/
	}

}
