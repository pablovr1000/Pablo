package main;

import java.util.ArrayList;
import java.util.List;

import model.Animal;
import model.Cachorro;
import model.Gato;

public class PetShop {

	public static void main(String[] args) {
		List<Animal> animais = new ArrayList<Animal>();
		
		Animal animal = new Cachorro("Rex");
		animal.setIdade(5);		
		animais.add(animal);
		
		animal = new Gato("Felix");
		animal.setIdade(3);		
		animais.add(animal);
		
		for (Animal a : animais) {
			System.out.println(a.getNome());
			System.out.println(a.getIdade());
			a.falar();
		}
		
	}

}
