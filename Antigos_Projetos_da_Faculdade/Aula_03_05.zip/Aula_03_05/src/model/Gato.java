package model;

public class Gato extends Animal {

	public Gato(String nome) {
		super.setNome(nome);
	}
	
	@Override
	public void falar() {
		System.out.println("Meow!");

	}

}
