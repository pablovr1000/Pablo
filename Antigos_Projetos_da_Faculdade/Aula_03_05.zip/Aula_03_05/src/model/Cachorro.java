package model;

public class Cachorro extends Animal {

	public Cachorro(String nome) {
		super.setNome(nome);
	}

	@Override
	public void falar() {
		System.out.println("Woof!");		
	}
	
}
